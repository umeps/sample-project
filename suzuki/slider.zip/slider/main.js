// footerのスライダー
$(".regular").slick({
    dots: true,
    infinite: true,
    slidesToShow: 2,
    slidesToScroll: 2,
    autoplay:true,
    autoplaySpeed:4000,
    adaptiveHeight: true,
    pauseOnHover:false,
      
  });

  $(".variable").slick({
    dots: true,
    infinite: true,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay:true,
    autoplaySpeed:4000,
    adaptiveHeight: true,
    pauseOnHover:false,
  });

  